# Bille
App Android de finanzas personales en CLP. Registra ingresos y gastos, presupuestos y gráficos locales.
Para compilar: GitHub Actions > Build Bille APK > Run workflow. Descarga Bille-APK en Artifacts.
Los datos se guardan localmente; no se conecta a bancos. No introduzcas PIN, CVV ni claves.
